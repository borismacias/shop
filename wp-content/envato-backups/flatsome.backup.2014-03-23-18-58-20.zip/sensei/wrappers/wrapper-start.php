<?php
/**
 * Content wrappers
 *
 * @author 		WooThemes
 * @package 	Sensei/Templates
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

echo '<div class="sensei-page" style="padding-top:30px;"><div class="row"><div class="large-12 columns">';

?>